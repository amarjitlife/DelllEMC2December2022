
#include <stdio.h>
#include <limits.h>

//__________________________________________________

int sum(signed int x, signed int y) {
	  signed int result;
	  // Type Definition
	  if (((y > 0 ) && (x > (INT_MAX - y))) ||
	      ((y < 0) && (x < (INT_MIN - y)))) {
	  	printf("\nCan't Calculate Sum");
	  } else {
	    result = x + y;
	  	return result;
	  }
	  /* ... */
}

//__________________________________________________

void playWithArray() {
	int a[10] = { 10, 20, 30, 40, 50, 60, 70, 80, 90, 99 };

	int start = -10;
	for( int i = start ; i < 10 ; i++) {
		printf("#  %d  #", a[i]);
	}
} 

//__________________________________________________

void playWithChar() {
	char ch = 0;

	for( ; ch < 255 ; ch++ ) {
		printf(" %d : %c ", ch, ch);
	}
}


//__________________________________________________


// Function Type
// (int, int) -> int
int unsafeSum(int x, int y) { return x + y; }
int unsafeSub(int x, int y) { return x - y; }

// Function Type
// (int, int, int) -> int
int unsafeSum3(int x, int y, int z) { return x + y + z; }

void playWithFunctions() {
	int a = 10, b = 20, result = 0;

	int (*operation)(int, int);
	operation = unsafeSum;

	result = unsafeSum( a, b );
	printf("\n Result : %d", result);

	result = operation( a, b );
	printf("\n Result : %d", result);

	operation = unsafeSum3;
}

//__________________________________________________

// struct human_type {

// }

void playWithImmutability() {
	const int a = 20;
	int *aptr = &a;

	printf("\n Value: %d", a, *aptr);
}

//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________

int main() {
	printf("\n\nFunction: playWithArray");
	playWithArray();
	
	printf("\n\nFunction: playWithChar");
	playWithChar();

	printf("\n\nFunction: playWithFunctions");
	playWithFunctions();

	printf("\n\nFunction: playWithImmutability");
	playWithImmutability();
	
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	return 0;
}
