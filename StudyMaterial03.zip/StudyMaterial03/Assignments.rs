

READING ASSINMENT

	Reference Material:
		The Rust Programming Language Book
		Link: https://doc.rust-lang.org/stable/book/

		4. Understanding Ownership 		[ MUST MUST ]
		3. Common Programming Concepts 	[ MUST ]

	Reference Material:
		The C Programming Language, 2nd Edition Book
			By Kernigham and Dennis Ritchie

		1. Data Types Chapter
		2. Array and Pointers Chapter	

