
use std::io;
use rand::Rng;
use std::cmp::Ordering;

// DESIGN PRINCIPLE
//      DESIGN TOWARDS IMMUTABILITY RATHER THAN MUTABILITY


fn main() {    
    println!("Guess The Number!");

    // let secret_number = Rng::rand::thread_rng().gen_range(1..=100);
    let secret_number = rand::thread_rng().gen_range(1..=100);

    println!("Generate Random Number: {secret_number}");

    loop { // Infinite Loop
        println!("Input Your Guess Number:");

        let mut guess = String::new();

        // Chaining The Functions
        io::stdin()
            .read_line( &mut guess )
            .expect("Failed To Read Line!");

    // let guess_trimmed = guess.trim();
    // 27 |     let guess_trimmed = guess.trim();
    //    |         ^^^^^^^^^^^^^ help: if this is intentional, 
    //                            prefix it with an underscore: `_guess_trimmed`

        // let guess = guess.trim();
        let guess: u32 = match guess.trim().parse() {
            Ok(num)     => num,
            Err(_)      => continue,
        };

        // Following Line Of Code Is
        //      Equivalent To Above Code
        // io::stdin().read_line( &mut guess ).expect("Failed To Read Line!");

        println!("You Guessed: {guess}");

        // match Used To Match Multiple Options
        // let secret_number_string = secret_number.to_string();
        //println!("")

        // Pattern Matching
        // match guess.cmp( &secret_number_string ) {
        
        // match Is A Type Safe Expression
        //      Type Safe : Respect Type Definition

        match guess.cmp( &secret_number ) {
            // matches Arms: It will execute body following
            //     Arm matching.
            Ordering::Less      => println!("Too Small!"),
            Ordering::Greater   => println!("Too Big!"),
            Ordering::Equal     => {
                println!("You Win!!!!");
                break;
            }
        }
    }
}

