

let some: UInt8 = 255
let one: UInt8 = 1

let result = some + one

