
use std::io;
use rand::Rng;
use std::cmp::Ordering;

//_________________________________________________________
//_________________________________________________________

// DESIGN PRINCIPLE
//      DESIGN TOWARDS IMMUTABILITY RATHER THAN MUTABILITY

// PLEASE DON"T USE THIS
//      RATHER REMOVE DEAD CODE
#[allow(dead_code)]
fn play_with_guess() {    
    println!("Guess The Number!");

    // let secret_number = Rng::rand::thread_rng().gen_range(1..=100);
    let secret_number = rand::thread_rng().gen_range(1..=100);

    println!("Generate Random Number: {secret_number}");

    loop { // Infinite Loop
        println!("Input Your Guess Number:");

        let mut guess = String::new();

        // Chaining The Functions
        io::stdin()
            .read_line( &mut guess )
            .expect("Failed To Read Line!");

    // let guess_trimmed = guess.trim();
    // 27 |     let guess_trimmed = guess.trim();
    //    |         ^^^^^^^^^^^^^ help: if this is intentional, 
    //                            prefix it with an underscore: `_guess_trimmed`

        // let guess = guess.trim();
        let guess: u32 = match guess.trim().parse() {
            Ok(num)     => num,
            Err(_)      => continue,
        };

        // Following Line Of Code Is
        //      Equivalent To Above Code
        // io::stdin().read_line( &mut guess ).expect("Failed To Read Line!");

        println!("You Guessed: {guess}");

        // match Used To Match Multiple Options
        // let secret_number_string = secret_number.to_string();
        //println!("")

        // Pattern Matching
        // match guess.cmp( &secret_number_string ) {
        
        // match Is A Type Safe Expression
        //      Type Safe : Respect Type Definition

        match guess.cmp( &secret_number ) {
            // matches Arms: It will execute body following
            //     Arm matching.
            Ordering::Less      => println!("Too Small!"),
            Ordering::Greater   => println!("Too Big!"),
            Ordering::Equal     => {
                println!("You Win!!!!");
                break;
            }
        }
    }
}

//_________________________________________________________
//_________________________________________________________

fn play_with_ifelse() {
    // let condition = true;

    // // if-else An Expression
    // //      Have Return Value
    // //          Return Value Of Either if Block Or else Block
    // //          Return Vvalue Of if/else Block Is
    // //              Last Expression Evaluated In Block
    // let number = if condition { 5 } else { 6 };
    // println!("The Value Of Number : {number}");

    // let number = if condition { 
    //     println!("If Block Executed!...");
    //     let _ = 5 + 10 ;
    //     100 + 200
    // } 
    // else { 
    //     println!("Else Block Executed!...");
    //     let _ = 6 - 10;
    //     222 + 111
    // };

    // println!("The Value Of Number : {number}");

    // if condition { 
    //     println!("If Block Executed!...");
    //     let _ = 5 + 10 ;
    //     // 100 + 200
    //     // let _ = 100 + 200;
    //     100 + 200;
    // };

    // let number = if condition { 
    //     println!("If Block Executed!...");
    //     let _ = 5 + 10 ;
    //     // 100 + 200
    //     // let _ = 100 + 200;
    //     100 + 200;
    // };    

    let x = -10;

    // if x {
    // }

    if x == -10 {
        println!("If Branch");
    } else {
        println!("Else Branch");        
    }
}

//_________________________________________________________

fn play_with_shadowing() {
    let guess = "Ballee Ballee";
    println!("Guess Value : {guess}");

    // Variable Shadowing
    //      Can Resuse Already Defined Variable Name 
    //      With New Value
    let guess = "Oye Hoye!";
    println!("Guess Value : {guess}");

    let guess = 90;
    println!("Guess Value : {guess}");

    let mut spaces = "   ";
    // let length = spaces.len();

    // spaces = spaces.len();

    println!("Spaces Length: { }", spaces.len());
    spaces = "Ding Dong";
    println!("Spaces Length: { }", spaces);    
}

//_________________________________________________________

fn play_with_while() {
    let mut number = 3;
    while number != 0 {
        println!("{number}");
        number -= 1;
    }

    println!("Loop Endeded");

    let a = [10, 20, 30, 40, 50];
    let mut index = 0;

    while index < 5 {
        println!("The Value Is : {}", a[index]);
        index += 1;
    }
}

//_________________________________________________________

// BEST PRACTICE
//      Prefer for-in Loop Over Indexing Loops/While Loops

fn play_with_for() {
    let a = [10, 20, 30, 40, 50];
    
    for element in a {
        println!("The Value Is : {}", element );
    }
}

//_________________________________________________________

fn play_with_mutability() {
    let x = 5;
    println!("Value : {x}");

    // x = 6;
    // println!("Value : {x}");    

    let mut x = 10;
    println!("Value : {x}");    

    x = 100;
    println!("Value : {x}");    

    let x = 5;
    let x = x + 1;
    println!("Outside Value : {x}");    

    { // Local Scope
        // Shadow Outer x
        let x  =  x * 2;
        println!("Inside Value : {x}");    
        // println!("Outside Value : {::x}");    
    }

    println!("Outside Value : {x}");    
}

//_________________________________________________________

fn play_with_char() {
    // Unicode Characters
    let c = 'z';
    let z: char = 'ℤ'; // with explicit type annotation
    let heart_eyed_cat = '😻';

    println!("Value: {c}");
    println!("Value: {z}");
    println!("Value: {heart_eyed_cat}");
}

//_________________________________________________________
// COMPOUND TYPES

// Compound Types
//  Compound types can group multiple values into one type. 
//  Rust has two primitive compoundtypes: tuples and arrays.

#[allow(unused)]
fn play_with_tuple() {
// The Tuple Type
// A tuple is a general way of grouping together a number of values 
// with a variety of types intoone compound type. Tuples have a 
// fixed length: once declared, they cannot grow or shrink in size.
// We create a tuple by writing a comma-separated list of values 
// inside parentheses. Each position in the tuple has a type, and 
// the types of the different values in the tuple don’t have to be 
// the same. We’ve added optional type annotations

    let mut tup: (i32, f64, u8) = (500, 6.4, 1);
    let _t1 = (10, 20, "Ding", "Dong");
    let _t2 = (10, 20, "Ding");

    let _t3:(i32, f64, u8)= (10, 20.90, 10);

    // tup = _t1;
    // tup = _t2;
    // |           ^^ expected `f64`, found integer

    // Tuple Unpacking/Destructing
    let (x, y, z) = tup;

    println!("Value: {x}");
    println!("Value: {y}");
    println!("Value: {z}");    

    let first = tup.0;
    let second = tup.1;    
    let third = tup.2;    

    println!("Value: {first}");
    println!("Value: {second}");
    println!("Value: {third}");
}

//_________________________________________________________

#[allow(unused)]
fn play_with_array() {
    // An array is a single chunk of memory of a known, 
    // fixed size that can be allocated on the stack. 
    // You can access elements of an array using indexing, like this:

    let a = [10, 20, 30, 40, 50];
    let first   = a[0];
    let second  = a[1];

    println!("Value: {first}");
    println!("Value: {second}");

    // Index Out Of Bound Error
    // let some = a[6];
    // let some = a[-10];

    println!("Please Enter Array Index: ");

    let mut index = String::new();
    io::stdin()
        .read_line(&mut index)
        .expect("Failed To Read File");

    // let index: i32 = index
    let index: usize = index
        .trim()
        .parse()
        .expect("Index Is Not A Number");

    // The program resulted in a runtime error at the point of using 
    // an invalid value in the indexingoperation
    let element = a[index];

    println!("Value : {} at Index : {}", element, index);

    // Array With Element Type and Array Size Annotation
    let a: [i32; 5] = [1, 2, 3, 4, 5];

    let aa = [1, 2, 3, 4, 5];
    // let aa = [1, 2, 3, 4, 5, "Ding", "Dong"];

    for element in a {
        println!("Array a: {}", element);
    }

    let months = ["January", "February", "March", "April", "May", "June", "July",
                  "August", "September", "October", "November", "December"];
    for element in months {
        println!("Array a: {}", element);
    }
}

// The tuple without any values has a special name, unit. 
// This value and its corresponding typeare both written ()
// and represent an empty value or an empty return type. E
// xpressions implicitly return the unit value if they don’t 
// return any other value.

//_________________________________________________________


#[allow(unused)]
fn play_with_type_inferrencing_binding() {
    let i = 100;
    let f = 90.90;

    let a: [i32; 5] = [1, 2, 3, 4, 5];

    // RHS Inferred Type [i32; 5]
    // LHS Binded To Type [i32; 5]
    let aa = [1, 2, 3, 4, 5];
    // let aa = [1, 2, 3, 4, 5, "Ding", "Dong"];

    let condition = true;

    let number = if condition { 5 } else { 6 };
    println!("The Value Of Number : {number}");

    // let number: i32 = if condition { 5 } else { "Ding" };
    // println!("The Value Of Number : {number}");

    // let Is Statement i.e. Don't Have Return Value
    // let some = ( let something = 100 );

    let y = {
        let x = 3;
        x + 1
    };

    let mut counter = 0;
    let result = loop {
        counter += 1;
        if counter == 10 {
            break counter * 2;
        }
    };
}

//_________________________________________________________

fn function_one_argument( x: i32 ) {
    println!("Function One Called: {x}");
}

fn function_two_argument( x: i32, y: f64 ) {
    println!("Function One Called: {x} {y}");
}

fn some_function() -> i32 {
    println!("Function Called some_function");
    7
}

fn play_with_functions() {
    function_one_argument( 100 );
    function_two_argument( 200, 222.22 );

    let result = some_function();
    println!("Result : {result}");
}

//_________________________________________________________

fn play_with_loop() {
    
    let mut count = 0;
    
    // Label
    'counting_up: loop {
        println!("count = {count}");
        let mut remaining = 10;

        loop {
            println!("remaining = {remaining}");
            if remaining == 9 {
                break;
            }
            if count == 2 {
                break 'counting_up;
            }
            remaining -= 1;
        }

        count += 1;
    }
    println!("End count = {count}");
}


//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________

fn main() {
    // println!("\nFunction : play_with_guess");
    // play_with_guess();

    println!("\nFunction : play_with_ifelse");
    play_with_ifelse();

    println!("\nFunction : play_with_shadowing");
    play_with_shadowing();

    println!("\nFunction : play_with_while");
    play_with_while();

    println!("\nFunction : play_with_for");
    play_with_for();

    println!("\nFunction : play_with_mutability");
    play_with_mutability();

    println!("\nFunction : play_with_char");
    play_with_char();

    println!("\nFunction : play_with_tuple");
    play_with_tuple();

    println!("\nFunction : play_with_array");
    play_with_array();

    println!("\nFunction : play_with_type_inferrencing_binding");
    play_with_type_inferrencing_binding();

    println!("\nFunction : play_with_functions");
    play_with_functions();

    println!("\nFunction : play_with_loop");
    play_with_loop();
    
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");

}

