
// Checking Rust Version!
// 		rustc --version

// Compiling Rust Program With Rust Compiler
// rustc HelloWorld.rs

fn main() {
	println!("Hello World!");
}

