// use std::io;

//_________________________________________________________

fn say_hello( say: String ) {
    println!("Saying From Function: { }", say);
}

fn play_with_scope() {
    let greeting = "Good Evening!";
    println!("Say: {greeting}");

    {
        let hello = "Hello!"; 
        println!("Say: {hello}");
    }

    // println!("Say: {hello}");

    // let hello = "More Hello!!!!";
    let hello = String::from("More Hello!!!!");
    println!("Say: {hello}");

    let more = hello;

    println!("Say: {more}");
    // println!("Say: {hello}");

    say_hello( more );
    println!("Say: {more}");
}


//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________

fn main() {    
    println!("\nFunction : play_with_scope");
    play_with_scope();

    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
}
