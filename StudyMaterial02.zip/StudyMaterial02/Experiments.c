
#include <stdio.h>
#include <limits.h>

//__________________________________________________

int sum(signed int x, signed int y) {
	  signed int result;
	  // Type Definition
	  if (((y > 0 ) && (x > (INT_MAX - y))) ||
	      ((y < 0) && (x < (INT_MIN - y)))) {
	  	printf("\nCan't Calculate Sum");
	  } else {
	    result = x + y;
	  	return result;
	  }
	  /* ... */
}

//__________________________________________________

void playWithArray() {
	int a[10] = { 10, 20, 30, 40, 50, 60, 70, 80, 90, 99 };

	int start = -10;
	for( int i = start ; i < 10 ; i++) {
		printf("#  %d  #", a[i]);
	}
} 

//__________________________________________________

void playWithChar() {
	char ch = 0;

	for( ; ch < 255 ; ch++ ) {
		printf(" %d : %c ", ch, ch);
	}
}


//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________

int main() {
	printf("\n\nFunction: playWithArray");
	playWithArray();
	
	printf("\n\nFunction: playWithChar");
	playWithChar();

	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	return 0;
}
