
#include <stdio.h>
#include <limits.h>

//__________________________________________________

// GOOD DESIGN
int sumDesign1(signed int x, signed int y) {
	  signed int result;
	  // Type Definition
	  if (((y > 0 ) && (x > (INT_MAX - y))) ||
	      ((y < 0) && (x < (INT_MIN - y)))) {
	  	printf("\nCan't Calculate Sum");
	  } else {
	    result = x + y;
	  	return result;
	  }
	  /* ... */
}

//__________________________________________________

/*
// Return Value

int sumDesign2(signed int x, signed int y, signed int *error) {
	  signed int result;
	  // Type Definition
	  if (((y > 0 ) && (x > (INT_MAX - y))) ||
	      ((y < 0) && (x < (INT_MIN - y)))) {
	  	*error = 1;	
	  	// RETURN 
	  } else {
	    result = x + y;
	  	return result;
	  }
}

int error;
int result = sumDesign2(x, y, &error);
if error != 0 {
	// result
} else {
	// Error Happened
}

//__________________________________________________

enum Validity {
	INVALID,
	VALID
};

typedef struct result_type {
	int value;
	int valid;	
} Result;

Result sumDesign3(signed int x, signed int y) {
	  Result result = { 0, INVALID };
	  // Type Definition
	  if (((y > 0 ) && (x > (INT_MAX - y))) ||
	      ((y < 0) && (x < (INT_MIN - y)))) {
	  	result.valid = INVALID;
	  } else {
	    result.value = x + y;
	    result.valid = VALID;
	  }
	  return result;
}


Result result = sumDesign3(x, y);
if (result.valid) {
	// Use Valid Result
	result.valid;
} else {
	// Invalid Result Error Happened
}

//__________________________________________________

typedef struct optional_type {
	int value;
	int valid;	
} Optional;

Optional sumDesign3(signed int x, signed int y) {
	  Optional optional = { 0, INVALID };
	  // Type Definition
	  if (((y > 0 ) && (x > (INT_MAX - y))) ||
	      ((y < 0) && (x < (INT_MIN - y)))) {
	  	optional.valid = INVALID;
	  } else {
	    optional.value = x + y;
	    optional.valid = VALID;
	  }
	  return optional;
}


Optional result = sumDesign3(x, y);
if (result.valid) {
	// Use Valid Result
	result.valid;
} else {
	// Invalid Result Error Happened
}

//__________________________________________________

// // Kotlin
// int? sumDesign3(signed int x, signed int y) {
// 	  int? result = null;
// 	  // Type Definition
// 	  if (((y > 0 ) && (x > (INT_MAX - y))) ||
// 	      ((y < 0) && (x < (INT_MIN - y)))) {
// 	  	result = null
// 	  } else {
// 	  	result = x + y;
// 	  }
// 	  return optional;
// }

*/

//__________________________________________________

void playWithArray() {
	int a[10] = { 10, 20, 30, 40, 50, 60, 70, 80, 90, 99 };

	int start = -10;
	for( int i = start ; i < 10 ; i++) {
		printf("#  %d  #", a[i]);
	}
} 

//__________________________________________________

void playWithChar() {
	char ch = 0;

	for( ; ch < 255 ; ch++ ) {
		printf(" %d : %c ", ch, ch);
	}
}


//__________________________________________________


// Function Type
// (int, int) -> int
int unsafeSum(int x, int y) { return x + y; }
int unsafeSub(int x, int y) { return x - y; }

// Function Type
// (int, int, int) -> int
int unsafeSum3(int x, int y, int z) { return x + y + z; }

void playWithFunctions() {
	int a = 10, b = 20, result = 0;

	int (*operation)(int, int);
	operation = unsafeSum;

	result = unsafeSum( a, b );
	printf("\n Result : %d", result);

	result = operation( a, b );
	printf("\n Result : %d", result);

	// operation = unsafeSum3;
}

//__________________________________________________

void playWithImmutability() {
	// const int a = 20;
	// int *aptr = &a;

	// printf("\n Value: %d", a, *aptr);
}

//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________

int main() {
	printf("\n\nFunction: playWithArray");
	playWithArray();
	
	printf("\n\nFunction: playWithChar");
	playWithChar();

	printf("\n\nFunction: playWithFunctions");
	playWithFunctions();

	printf("\n\nFunction: playWithImmutability");
	playWithImmutability();
	
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	return 0;
}
