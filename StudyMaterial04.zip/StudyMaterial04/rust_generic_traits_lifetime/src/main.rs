#![allow(unused)]

//_________________________________________________________

// Function Type
//      ( &[i32] ) -> &i32

// fn largest(list: &[i32]) -> &i32 {
//     let mut largest = &list[0];

//     for item in list {
//         if item > largest {
//             largest = item;
//         }
//     }
//     largest
// }


// fn play_with_largest() {
//     let number_list = vec![34, 50, 25, 100, 65];

//     let result = largest(&number_list);
//     println!("The largest number is {}", result);
//     assert_eq!(*result, 100);

//     let number_list = vec![102, 34, 6000, 89, 54, 2, 43, 8];

//     let result = largest(&number_list);
//     println!("The largest number is {}", result);
//     assert_eq!(*result, 6000);
// }


//_________________________________________________________

// Generics/Templates
//      Code To Generate Code
// fn largest<T>(list: &[T]) -> &T {

// Function Type
//      Parametrised Type
//      ( &[T] ) -> &T where T is std::cmp::PartialOrd
fn largest<T : std::cmp::PartialOrd>(list: &[T]) -> &T {
    let mut largest = &list[0];

    for item in list {
        if item > largest {
            largest = item;
        }
    }
    largest
}

// // Compiler Will Generate Following Code
// //      Based On Usage
//     // let number_list: vec[i32] = vec![34, 50, 25, 100, 65];
//     // let result = largest(&number_list);

// fn largest_i32(list: &[i32]) -> &i32 {
//     let mut largest = &list[0];

//     for item in list {
//         if item > largest {
//             largest = item;
//         }
//     }

//     largest
// }

// // Compiler Will Generate Following Code
// //      Based On Usage
//     // let char_list: vec[char] = vec!['y', 'm', 'a', 'q'];
//     // let result = largest(&char_list);
// fn largest_char(list: &[char]) -> &char {
//     let mut largest = &list[0];

//     for item in list {
//         if item > largest {
//             largest = item;
//         }
//     }

//     largest
// }

fn play_with_largest_generic() {
    let number_list = vec![34, 50, 25, 100, 65];
    let result = largest(&number_list);
    println!("The largest number is {}", result);

    let char_list = vec!['y', 'm', 'a', 'q'];
    let result = largest(&char_list);
    println!("The largest char is {}", result);
}

//_________________________________________________________

struct Point<T> {
    x: T,
    y: T,
}

// Compiler Will Generate Code For Following Usage
    // let integer = Point { x: 5, y: 10 };

    // struct Point_i32 {
    //     x: i32,
    //     y: i32,
    // }

// Compiler Will Generate Code For Following Usage
    // let float = Point { x: 1.0, y: 4.0 };

    // struct Point_f64 {
    //     x: f64,
    //     y: f64,
    // }

fn play_with_point_generic() {
    let integer = Point { x: 5, y: 10 };

    let float = Point { x: 1.0, y: 4.0 };
}

//_________________________________________________________

struct Point1<T, U> {
    x: T,
    y: U,
}

fn play_with_point_generic_multiple() {
    let both_integer = Point1 { x: 5, y: 10 };
    let both_float = Point1 { x: 1.0, y: 4.0 };
    let integer_and_float = Point1 { x: 5, y: 4.0 };
}

//_________________________________________________________

struct Point2<T> {
    x: T,
    y: T,
}

impl<T> Point2<T> {
    fn x(&self) -> &T {
        &self.x
    }
}

impl Point2<f32> {
    fn distance_from_origin(&self) -> f32 {
        (self.x.powi(2) + self.y.powi(2)).sqrt()
    }
}

fn play_with_point_generic2() {
    let p = Point2 { x: 5, y: 10 };

    println!("p.x = {}", p.x());
}

//_________________________________________________________

struct Point3<X1, Y1> {
    x: X1,
    y: Y1,
}

impl<X1, Y1> Point3<X1, Y1> {
    
    fn mixup<X2, Y2>(self, other: Point3<X2, Y2>) -> Point3<X1, Y2> {
        Point3 {
            x: self.x,
            y: other.y,
        }
    }
}

fn play_with_point_generic3() {
    let p1 = Point3 { x: 5, y: 10.4 };
    let p2 = Point3 { x: "Hello", y: 'c' };

    let p3 = p1.mixup(p2);

    println!("p3.x = {}, p3.y = {}", p3.x, p3.y);
}

//_________________________________________________________

pub trait Summary {
    fn summarize(&self) -> String;
}

pub struct NewsArticle {
    pub headline: String,
    pub location: String,
    pub author: String,
    pub content: String,
}

impl Summary for NewsArticle {
    fn summarize(&self) -> String {
        format!("{}, by {} ({})", self.headline, self.author, self.location)
    }
}

pub struct Tweet {
    pub username: String,
    pub content: String,
    pub reply: bool,
    pub retweet: bool,
}

impl Summary for Tweet {
    fn summarize(&self) -> String {
        format!("{}: {}", self.username, self.content)
    }
}

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________

fn main() {    
    // println!("\nFunction : play_with_largest");
    // play_with_largest();

    println!("\nFunction : play_with_largest_generic");
    play_with_largest_generic();

    println!("\nFunction : play_with_point_generic");
    play_with_point_generic();

    println!("\nFunction : play_with_point_generic_multiple");
    play_with_point_generic_multiple();

    println!("\nFunction : play_with_point_generic2");
    play_with_point_generic2();

    println!("\nFunction : play_with_point_generic3");
    play_with_point_generic3();

    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
}
