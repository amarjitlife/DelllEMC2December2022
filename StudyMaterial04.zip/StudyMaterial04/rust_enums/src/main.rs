#![allow(unused)]

//_________________________________________________________

enum IpAddrKind {
    V4,
    V6,
}

fn route(ip_kind: IpAddrKind) {}

fn play_with_ipaddress_enum () {
    let four = IpAddrKind::V4;
    let six = IpAddrKind::V6;

    route(IpAddrKind::V4);
    route(IpAddrKind::V6);
}

//________________________________________________________

fn play_with_ipaddress_enum1() {
    enum IpAddrKind {
        V4,
        V6,
    }

    struct IpAddr {
        kind: IpAddrKind,
        address: String,
    }

    let home = IpAddr {
        kind: IpAddrKind::V4,
        address: String::from("127.0.0.1"),
    };

    let loopback = IpAddr {
        kind: IpAddrKind::V6,
        address: String::from("::1"),
    };
}

//_________________________________________________________

fn play_with_ipaddress_enum2() {
    enum IpAddr {
        V4(String),
        V6(String),
    }

    let home = IpAddr::V4(String::from("127.0.0.1"));
    let loopback = IpAddr::V6(String::from("::1"));
}

//_________________________________________________________

fn play_with_ipaddress_enum3() {
    enum IpAddr {
        V4(u8, u8, u8, u8),
        V6(String),
    }

    let home = IpAddr::V4(127, 0, 0, 1);
    let loopback = IpAddr::V6(String::from("::1"));
}

//_________________________________________________________

fn play_with_ipaddress_enum4() {
    struct Ipv4Addr {
        // --snip--
    }

    struct Ipv6Addr {
        // --snip--
    }

    enum IpAddr {
        V4(Ipv4Addr),
        V6(Ipv6Addr),
    }
}

//_________________________________________________________


fn play_with_message_enum() {
    enum Message {
        Quit,
        Move { x: i32, y: i32 },
        Write(String),
        ChangeColor(i32, i32, i32),
    }

    impl Message {
        fn call(&self) {
            // method body would be defined here
        }
    }

    let m = Message::Write(String::from("hello"));
    m.call();
}

//_________________________________________________________

fn play_with_optional() {
    let some_number = Some(5);
    let some_char = Some('e');

    let absent_number: Option<i32> = None;
}

//_________________________________________________________

fn play_with_optionals() {
    let some_number = Some(5);
    let some_char = Some('e');

    let absent_number: Option<i32> = None;

    let x: i8 = 5;
    let y: Option<i8> = Some(5);

    // let sum = x + y;
}

//_________________________________________________________

enum Coin {
    Penny,
    Nickel,
    Dime,
    Quarter,
}

fn value_in_cents(coin: Coin) -> u8 {
    match coin {
        Coin::Penny => 1,
        Coin::Nickel => 5,
        Coin::Dime => 10,
        Coin::Quarter => 25,
    }
}

fn value_in_cents1(coin: Coin) -> u8 {
    match coin {
        Coin::Penny => {
            println!("Lucky penny!");
            1
        }
        Coin::Nickel => 5,
        Coin::Dime => 10,
        Coin::Quarter => 25,
    }
}

fn play_with_coins() {
    println!("Value : {}", value_in_cents( Coin::Penny ));
    println!("Value : {}", value_in_cents( Coin::Dime ));
    println!("Value : {}", value_in_cents( Coin::Quarter ));

    println!("Value : {}", value_in_cents1( Coin::Penny ));
    println!("Value : {}", value_in_cents1( Coin::Dime ));
    println!("Value : {}", value_in_cents1( Coin::Quarter ));
}


//_________________________________________________________

#[derive(Debug)]
enum UsState {
    Alabama,
    Alaska,
    // --snip--
}

enum Coin1 {
    Penny,
    Nickel,
    Dime,
    Quarter(UsState),
}

fn value_in_cents2(coin: Coin1) -> u8 {
    match coin {
        Coin1::Penny => 1,
        Coin1::Nickel => 5,
        Coin1::Dime => 10,
        Coin1::Quarter(state) => {
            println!("State: {:?}!", state);
            25
        }
    }
}

fn play_with_coins_state() {
    println!("Value : {}", 
        value_in_cents2(Coin1::Quarter(UsState::Alaska)));
    println!("Value : {}", 
        value_in_cents2(Coin1::Quarter(UsState::Alabama)));

    println!("Value : {}", value_in_cents2( Coin1::Penny ));
    println!("Value : {}", value_in_cents2( Coin1::Dime ));
}

//_________________________________________________________

fn play_with_returing_optional() {

    fn plus_one(x: Option<i32>) -> Option<i32> {
        match x {
            None => None,
            Some(i) => Some(i + 1),
        }
    }

    let five = Some(5);
    let six = plus_one(five);
    let none = plus_one(None);

    // fn plus_one_again(x: Option<i32>) -> Option<i32> {
    //     match x {
    //         Some(i) => Some(i + 1),
    //     }
    // }

    // let five1 = Some(5);
    // let six1 = plus_one_again(five);
    // let none1 = plus_one_again(None);
}

//_________________________________________________________

// IMPLEMENT FOLLOIWNG sum FUNCTION CODE IN RUST
//     USING RUST Optional Types

// Optional sumDesign3(signed int x, signed int y) {
//       Optional optional = { 0, INVALID };
//       // Type Definition
//       if (((y > 0 ) && (x > (INT_MAX - y))) ||
//           ((y < 0) && (x < (INT_MIN - y)))) {
//         optional.valid = INVALID;
//       } else {
//         optional.value = x + y;
//         optional.valid = VALID;
//       }
//       return optional;
// }

//_________________________________________________________

fn play_with_match_default() {
    let dice_roll = 9;
    match dice_roll {
        3 => add_fancy_hat(),
        7 => remove_fancy_hat(),
        other => move_player(other), // Default Case
    }

    fn add_fancy_hat() {}
    fn remove_fancy_hat() {}
    fn move_player(num_spaces: u8) {}
}

//_________________________________________________________

fn play_with_match_underscore() {
    let dice_roll = 9;
    match dice_roll {
        3 => add_fancy_hat(),
        7 => remove_fancy_hat(),
        _ => reroll(),
    }

    fn add_fancy_hat() {}
    fn remove_fancy_hat() {}
    fn reroll() {}
}

//_________________________________________________________


fn play_with_match_underscore1() {
    let dice_roll = 9;
    match dice_roll {
        3 => add_fancy_hat(),
        7 => remove_fancy_hat(),
        _ => (),
    }

    fn add_fancy_hat() {}
    fn remove_fancy_hat() {}
}

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________


fn main() {    
    println!("\nFunction : play_with_ipaddress_enum1");
    play_with_ipaddress_enum();

    println!("\nFunction : play_with_ipaddress_enum1");
    play_with_ipaddress_enum1();

    println!("\nFunction : play_with_ipaddress_enum2");
    play_with_ipaddress_enum2();

    println!("\nFunction : play_with_ipaddress_enum3");
    play_with_ipaddress_enum3();

    println!("\nFunction : play_with_ipaddress_enum4");
    play_with_ipaddress_enum4();

    println!("\nFunction : play_with_message_enum");
    play_with_message_enum();

    println!("\nFunction : play_with_optionals");
    play_with_optionals();

    println!("\nFunction : play_with_coins");
    play_with_coins();

    println!("\nFunction : play_with_coins_state");
    play_with_coins_state();

    println!("\nFunction : play_with_returing_optional");
    play_with_returing_optional();

    println!("\nFunction : play_with_match_default");
    play_with_match_default();

    println!("\nFunction : play_with_match_underscore");
    play_with_match_underscore();

    println!("\nFunction : play_with_match_underscore1");
    play_with_match_underscore1();
    
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
}
