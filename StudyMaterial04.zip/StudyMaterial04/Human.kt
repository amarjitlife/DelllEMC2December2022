
// DESIGN PRINCIPLE
//		Design Towards Abstract Type Rather Than Concrete Types

// Protocol/Contract
//		What It Will Do!
// Abstract Type
//		Operation = { fly, saveWorld }
interface Superpower {
	fun fly()
	fun saveWorld()
}

// Concrete Classes/Types
//	 How/When/Where/Which Way... It Will Do!
class Spiderman : Superpower {
	override fun fly() 		{ println("Fly Like Spiderman!") }
	override fun saveWorld() { println("SaveWorld Like Spiderman!") }
}

class Superman : Superpower {
	override fun fly() 		 { println("Fly Like Superman!") }
	override fun saveWorld() { println("SaveWorld Like Superman!") }
}

open class Heman {
	open fun fly() 		 { println("Fly Like Heman!") }
	open fun saveWorld() { println("SaveWorld Like Heman!") }
}

//____________________________________________________

// Using Inheritance
class HumanD1 : Heman() {
	override fun fly() 		 { super.fly() 		}
	override fun saveWorld() { super.saveWorld() }
}

//____________________________________________________

// Using Composition
class HumanD2 {
	var power: Superpower? = null
	fun fly() 		{ power?.fly() 		 }
	fun saveWorld() { power?.saveWorld() }	
}

//____________________________________________________

fun main() {
	val human1 = HumanD1()
	human1.fly()
	human1.saveWorld()

	// val spiderman = Spiderman()
	// spiderman.fly()
	// spiderman.saveWorld()

	val human2 = HumanD2()
	human2.power = Spiderman()
	human2.fly()
	human2.saveWorld()

	human2.power = Superman()
	human2.fly()
	human2.saveWorld()
}

