
#include <stdio.h>

// Polymorphic Human
typedef struct human_type {
	int id;
	char name[100];
	void (*dance)();
} Human;

void doBhangra() {
	printf("\n Balleeee Balleeee....!!!");
}

void doBreakDance() {
	printf("\n Break Legs....!!!");
}

int playWithHuman() {
	//				Constructor
	Human gabbar = { 420, "Gabbar Singh", doBhangra };

	printf("\nID 	: %d", gabbar.id);
	printf("\nName 	: %s", gabbar.name);
	gabbar.dance();

	gabbar.dance = doBreakDance;
	gabbar.dance();
}

//________________________________________

int sum( int x, int y ) { return x + y; }
int sub( int x, int y ) { return x - y; }

// Polymorphic Function
// Function Type
//		(int, int, (int, int) -> int) -> int
int calculator(int x, int y, int (*operate )(int, int)) {
	return operate(x, y);
}

void playWithCalculator() {
	int result = 0;

	result = calculator( 10, 20, sum );
	printf("\nResult : %d", result);

	result = calculator( 60, 20, sub );
	printf("\nResult : %d", result);
}

//________________________________________
//________________________________________
//________________________________________
//________________________________________
//________________________________________

int main() {
	playWithHuman();
	playWithCalculator();
}
