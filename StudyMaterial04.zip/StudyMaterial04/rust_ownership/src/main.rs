#![allow(unused)]

// use std::io;

//_________________________________________________________

// What Is Ownership?
// Ownership is a set of rules that governs 
//  how a Rust program manages memory

// Some languageshave garbage collection that regularly looks for 
// no-longer used memory as the program runs; in other languages, 
// the programmer must explicitly allocate and free the memory. 

 // Rustuses a third approach: memory is managed through a system 
// of ownership with a set of rules that the compiler checks. 
// If any of the rules are violated, the program won’t compile.
// None of the features of ownership will slow down your program 
// while it’s running.

// NOTE : main purpose of ownership is to manage heap data

fn say_hello( say: String ) {
    println!("Saying From Function: { }", say);
}

fn play_with_scope() {
    let greeting = "Good Evening!";
    println!("Say: {greeting}");

    {
        let hello = "Hello!"; 
        println!("Say: {hello}");
    }

    // println!("Say: {hello}");

    // Following String Literal Stored In Code Area
    // let hello = "More Hello!!!!";
    
    // Following String Object Stored At Heap
    let hello = String::from("More Hello!!!!");

    println!("Say: {hello}");

    let more = hello; // Move 

    println!("Say: {more}");
    // println!("Say: {hello}");

    say_hello( more );
    // println!("Say: {more}");

    let x = 10;
    let y = x; // Copy Semantic

    println!("Say: {x}");
    println!("Say: {y}");

    let s1 = String::from("Dell");
    let s2 = s1; // Move Semantic

    // println!("Say: {s1}");
    println!("Say: {s2}");

    let s11 = String::from("Dell Inc.");
    let s22 = s11.clone();

    println!("Say: {s11}");
    println!("Say: {s22}");
}


//_________________________________________________________

// Ownership Rules. 
//  1. Each value in Rust has an owner
//  2. There can only be one owner at a time.
//  3. When the owner goes out of scope, the value will be dropped

// NOTE:
// We need to pair exactly one allocate with exactly one free
// Rust takes a different path: the memory is automatically 
// returned once the variable that owns it goes out of scope. 

//_________________________________________________________

// Here are some of the types that implement Copy:

// All the integer types, such as u32.
// The Boolean type, bool, with values true and false.
// All the floating point types, such as f64.
// The character type, char.
// Tuples, if they only contain types that also implement Copy. 
// For example, (i32, i32) implements Copy, but (i32, String) 
// does not.

//_________________________________________________________



fn takes_ownership(some_string: String) { // some_string comes into scope
    println!("{}", some_string);
} // Here, some_string goes out of scope and `drop` is called. The backing
  // memory is freed.

fn makes_copy(some_integer: i32) { // some_integer comes into scope
    println!("{}", some_integer);
} // Here, some_integer goes out of scope. Nothing special happens.

fn play_with_copy_move() {
    let s = String::from("hello");  // s comes into scope

    takes_ownership(s);             // s's value moves into the function...
                                    // ... and so is no longer valid here

    let x = 5;                      // x comes into scope

    makes_copy(x);                  // x would move into the function,
                                    // but i32 is Copy, so it's okay to still
                                    // use x afterward

} // Here, x goes out of scope, then s. But because s's value was moved, nothing
  // special happens.

//_________________________________________________________


fn gives_ownership() -> String {             // gives_ownership will move its
    // string some_string = new string();
                                             // return value into the function
                                             // that calls it
    let some_string = String::from("yours"); // some_string comes into scope
    some_string                              // some_string is returned and
                                             // moves out to the calling
                                             // function
}

// This function takes a String and returns one
fn takes_and_gives_back(a_string: String) -> String { // a_string comes into
                                                      // scope
    a_string  // a_string is returned and moves out to the calling function
}

fn play_with_giving_ownershio() {
    let s1 = gives_ownership();         // gives_ownership moves its return
                                        // value into s1
    let s2 = String::from("hello");     // s2 comes into scope
    let s3 = takes_and_gives_back(s2);  // s2 is moved into
                                        // takes_and_gives_back, which also
                                        // moves its return value into s3
} // Here, s3 goes out of scope and is dropped. s2 was moved, so nothing
  // happens. s1 goes out of scope and is dropped.

//_________________________________________________________

 // Instead, we can provide a reference to the String value. A reference is like a pointer in that it’s an address we can follow to access the data stored at that address; that data is owned by some other variable. Unlike a pointer, a reference is guaranteed to point to a valid value of a particular type for the life of that reference.


// When functions have references as parameters instead of the actual values, we won’t need to return the values in order to give back ownership, because we never had ownership.

// We call the action of creating a reference borrowing. As in real life

fn calculate_length(s: &String) -> usize {
    s.len()
}

fn play_with_references() {
    let s1 = String::from("hello");

    let len = calculate_length(&s1);

    println!("The length of '{}' is {}.", s1, len);
}

//_________________________________________________________


fn change(some_string: &mut String) {
    some_string.push_str(", world");
}

fn play_with_borrowing() {
    let mut s = String::from("hello");

    change(&mut s);
}

fn play_with_mutabable_references() {
    let mut s = String::from("hello");

    let r1 = &mut s;
    // Compilation Error :

    //Mutable references have one big restriction: 
    // if you have a mutable reference to a value
    //  It Must Be Only One Mutable Reference

    // let r2 = &mut s;

    // println!("{}, {}", r1, r2);

// The restriction preventing multiple mutable references to the same data at the same time allows for mutation but in a very controlled fashion. It’s something that new Rustaceans struggle with, because most languages let you mutate whenever you’d like. The benefit of having this restriction is that Rust can prevent data races at compile time. A data race is similar to a race condition and happens when these three behaviors occur:

//  Two or more pointers access the same data at the same time.
//  At least one of the pointers is being used to write to the data.
//  There’s no mechanism being used to synchronize access 
//      to the data.

    let mut s = String::from("hello");

    let r1 = &s; // no problem
    let r2 = &s; // no problem
    let r3 = &s;
    // let r3 = &mut s; // BIG PROBLEM

    println!("{}, {}, and {}", r1, r2, r3);


    let mut s = String::from("hello");

    let r1 = &s; // no problem
    let r2 = &s; // no problem
    println!("{} and {}", r1, r2);
    // variables r1 and r2 will not be used after this point

    // The ability of the compiler to tell that a reference is no longer being used at a point before the end of the scope is called Non-Lexical Lifetimes (NLL for short), 
    let r3 = &mut s; // no problem
    println!("{}", r3);
}

//_________________________________________________________

// fn dangle() -> &String {
//     let s = String::from("hello");

//     &s
// }

fn dangle() -> String {
    let s = String::from("hello");

    s
}

fn play_with_dangle() {
    let reference_to_nothing = dangle();
}

// Dangling References
// In languages with pointers, it’s easy to erroneously create a dangling pointer--a pointer that references a location in memory that may have been given to someone else--by freeing some memory while preserving a pointer to that memory. In Rust, by contrast, the compiler guarantees that references will never be dangling references: if you have a reference to some data, the compiler will ensure that the data will not go out of scope before the reference to the data does.

//_________________________________________________________

// The Rules of References
// At any given time, you can have either one mutable reference 
// or any number of immutable references.
// References must always be valid.

//_________________________________________________________

fn first_word(s: &String) -> usize {
    let bytes = s.as_bytes();

    for (i, &item) in bytes.iter().enumerate() {
        if item == b' ' {
            return i;
        }
    }
    s.len()
}

fn play_with_first_word() {
    let mut sentence = String::from("How are you doing?");

    println!("Sentence : {sentence}");

    let word = first_word( &sentence );
    println!("\nResult : {word}");

    sentence.clear();
    println!("Sentence : {sentence}");

}

//_________________________________________________________


fn first_word_better(s: &String) -> &str { //String {
    let bytes = s.as_bytes();

    for (i, &item) in bytes.iter().enumerate() {
        if item == b' ' {
            return &s[0..i];
        }
    }
    // s.len()
    &s[..]
}

fn play_with_first_word_better() {
    let mut sentence = String::from("How are you doing?");

    println!("Sentence : {sentence}");

    let word = first_word_better( &sentence );
    println!("\nWord : {word}");

    sentence.clear();
    println!("Sentence : {sentence}");

}

//_________________________________________________________

fn first_word_best(s: &str) -> &str { //String {
    let bytes = s.as_bytes();

    for (i, &item) in bytes.iter().enumerate() {
        if item == b' ' {
            return &s[0..i];
        }
    }
    // s.len()
    &s[..]
}

fn play_with_first_word_best() {
    let my_string = String::from("hello world");

    // `first_word` works on slices of `String`s, whether partial or whole
    let word = first_word_best(&my_string[0..6]);
    let word = first_word_best(&my_string[..]);
    // `first_word` also works on references to `String`s, which are equivalent
    // to whole slices of `String`s
    let word = first_word_best(&my_string);

    let my_string_literal = "hello world";

    // `first_word` works on slices of string literals, whether partial or whole
    let word = first_word_best(&my_string_literal[0..6]);
    let word = first_word_best(&my_string_literal[..]);

    // Because string literals *are* string slices already,
    // this works too, without the slice syntax!
    let word = first_word_best(my_string_literal);
}

// Note: String slice range indices must occur at valid UTF-8 character boundaries. If you attempt to create a string slice in the middle of a multibyte character, your program will exit with an error. For the purposes of introducing string slices, we are assuming ASCII only in this section; a more thorough discussion of UTF-8 handling is in the “Storing UTF-8 Encoded Text with Strings” section

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________


fn main() {    
    println!("\nFunction : play_with_scope");
    play_with_scope();

    println!("\nFunction : play_with_references");
    play_with_references();

    println!("\nFunction : play_with_borrowing");
    play_with_borrowing();

    println!("\nFunction : play_with_mutabable_references");
    play_with_mutabable_references();

    println!("\nFunction : play_with_dangle");
    play_with_dangle();

    println!("\nFunction : play_with_first_word");
    play_with_first_word();

    println!("\nFunction : play_with_first_word_better");
    play_with_first_word_better();

    println!("\nFunction : play_with_first_word_best");
    play_with_first_word_best();
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
}
