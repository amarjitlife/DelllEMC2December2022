
#![allow(unused)]

//_________________________________________________________

struct User {
    active: bool,
    username: String,
    email: String,
    sign_in_count: u64,
}

fn play_with_user() {
    let user = User {
        active: true,
        username: String::from("Mansa"),
        email:String::from("Dell"),
        sign_in_count: 1,
    };

    let mut user1 = User {
        active: true,
        username: String::from("Mansa"),
        email:String::from("Dell"),
        sign_in_count: 1,
    };

    user1.email = String::from("mansa@dell.com");

    // let user2 = User {
    //     mut active: true,
    //     username: String::from("Mansa"),
    //     email:String::from("Dell"),
    //     sign_in_count: 1,
    // };

    let user3 = User {
        email:String::from("Dell"),
        username: String::from("Mansa"),
        sign_in_count: 1,
        active: true,
    };

    let user4 = User {
        active: true,
        username: user1.username,
        email: user1.email,
        sign_in_count: user1.sign_in_count,
    };

    let user5 = User {
        active: false,
        ..user3
    };

}

//_________________________________________________________


fn build_user( email : String, username: String) -> User {
    User {
        active: true,
        username: username,
        email: email,
        sign_in_count: 1,
    }
}

fn build_user_better( email : String, username: String) -> User {
    User {
        active: true,
        username,
        email,
        sign_in_count: 1,
    }
}

fn play_with_build_user() {
    let mansa = build_user( String::from("mansa@dell.com"),
                            String::from("mansa"));

    let mansa1 = build_user_better( String::from("mansa@dell.com"),
                            String::from("mansa"));

}


//_________________________________________________________

fn area(width: u32, height: u32) -> u32 {
    width * height
}

fn area_better(dimentions: (u32, u32)) -> u32 {
   dimentions.0 * dimentions.1
}

#[derive(Debug)]
struct Rectangle {
    width: u32,
    height: u32,
}

fn area_best( rectangle : Rectangle )  -> u32 {
   rectangle.width * rectangle.height
}

fn play_with_area() {
    let width1 = 30;
    let height1 = 50;

    let result = area(width1, height1);
    println!("Rectangle Area: {}", result);

    let result = area_better( (width1, height1) );
    println!("Rectangle Area: {}", result);

    let rectangle = Rectangle {
        width: 30,
        height: 50,
    };

    println!("Rectangle : {:?} ", rectangle );
    let result = area_best( rectangle );
    println!("Rectangle Area: {}", result);
}


//_________________________________________________________

struct Color(i32, i32, i32);
struct Point(i32, i32, i32);

fn play_with_custom_tuple_types() {
    let black = Color(0, 0, 0);
    let origin = Point(0, 0, 0);

    // let black1 : Color(i32, i32, i32) = Color(250, 250, 250);
    // let origin1: Point(i32, i32, i32) = Point(0, 10, 10);

    // let black1 : (i32, i32, i32) = Color(250, 250, 250);
    // let origin1: (i32, i32, i32) = Point(0, 10, 10);

    let mut black2 = Color(0, 0, 0);
    let origin2 = Point(0, 0, 0);    

    // Color Type != Point Type
    //      Type Name Is Part Of Type
    // black2 = origin2;
}

//_________________________________________________________

// struct User1 {
//     active: bool,
//     username: &str,
//     email: &str,
//     sign_in_count: u64,
// }

// fn play_with_user1() {
//     let user1 = User {
//         email: String::from("someone@example.com"),
//         username: String::from("someusername123"),
//         active: true,
//         sign_in_count: 1,
//     };
// }

//_________________________________________________________

#[derive(Debug)]
struct Rectangle1 {
    width: u32,
    height: u32,
}

// Implementation Block
//      Contains Methods Implementation
impl Rectangle1 {
    fn area( &self ) -> u32 {
        self.width * self.height
    }

    fn width(&self) -> bool {
        self.width > 0
    }

    fn can_hold(&self, other: &Rectangle1) -> bool {
        self.width > other.width && self.height > other.height
    }

    fn square(size: u32) -> Self {
        Self {
            width: size,
            height: size,
        }
    }
}

fn play_with_rectangle_area() {
    let rect1 = Rectangle1 {
        width: 30,
        height: 50,
    };

    println!("Rectangle Area: {}", rect1.area() );
    println!("Rectangle Width: {}", rect1.width() );
}

//_________________________________________________________

fn play_with_can_hold() {
    let rect1 = Rectangle1 {
        width: 30,
        height: 50,
    };
    let rect2 = Rectangle1 {
        width: 10,
        height: 40,
    };
    let rect3 = Rectangle1 {
        width: 60,
        height: 45,
    };

    println!("Can rect1 hold rect2? {}", rect1.can_hold(&rect2));
    println!("Can rect1 hold rect3? {}", rect1.can_hold(&rect3));
}

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________

fn main() {
    println!("\nFunction : play_with_user");
    play_with_user();

    println!("\nFunction : play_with_build_user");
    play_with_build_user();

    println!("\nFunction : play_with_area");
    play_with_area();

    println!("\nFunction : play_with_custom_tuple_types");
    play_with_custom_tuple_types();

    // println!("\nFunction : play_with_user1");
    // play_with_user1();

    println!("\nFunction : play_with_rectangle_area");
    play_with_rectangle_area();

    println!("\nFunction : play_with_can_hold");
    play_with_can_hold();

    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
    // println!("\nFunction : ");
}
